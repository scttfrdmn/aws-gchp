# every data variable end to end, netCDF4 (the arm that showed +22.3% on hco)
import sys, time
from netCDF4 import Dataset
ds = Dataset(sys.argv[1])
dv = [n for n, v in ds.variables.items() if v.ndim >= 3]
t0 = time.time(); tot = 0
for n in dv:
    a = ds.variables[n][:]; tot += a.nbytes; del a
print("ncwhole vars=%d elem_bytes=%d wall=%.1f" % (len(dv), tot, time.time() - t0))
ds.close()
