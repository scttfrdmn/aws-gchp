# whole object, strictly increasing 1 MiB preads: contiguous, but from python
import os, sys, time
fd = os.open(sys.argv[1], os.O_RDONLY)
sz = os.fstat(fd).st_size
t0 = time.time(); off = 0; n = 0
while off < sz:
    b = os.pread(fd, 1 << 20, off)
    if not b:
        break
    off += len(b); n += 1
os.close(fd)
print("pystream bytes=%d reads=%d wall=%.1f" % (off, n, time.time() - t0))
