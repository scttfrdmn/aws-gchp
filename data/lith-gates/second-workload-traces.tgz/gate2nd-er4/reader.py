import sys, time
import numpy as np
from netCDF4 import Dataset

path, mode = sys.argv[1], sys.argv[2]
ds = Dataset(path)
dvars = [n for n, v in ds.variables.items() if v.ndim >= 3]
t0 = time.time()
elem = 0

if mode == "whole":
    # every data variable, end to end
    for n in dvars:
        a = ds.variables[n][:]
        elem += a.nbytes
        del a
elif mode == "var1":
    # ONE variable, end to end: low coverage of the object, perfectly sequential in it
    n = dvars[0]
    a = ds.variables[n][:]
    elem += a.nbytes
    del a
elif mode == "sub":
    # ExtData-like: one chunk-sized plane per variable at two time steps
    for n in dvars:
        v = ds.variables[n]
        ck = v.chunking()
        for t in (0, v.shape[0] // 2):
            if v.ndim == 4:
                a = v[t, 0, :, :]
            else:
                a = v[t, 0:ck[1], 0:ck[2]]
            elem += a.nbytes
            del a
else:
    sys.exit("bad mode " + mode)

print("mode=%s vars=%d elem_bytes=%d wall=%.1f" % (mode, len(dvars), elem, time.time() - t0))
ds.close()
