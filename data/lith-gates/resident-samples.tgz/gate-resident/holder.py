import os, sys, time
n, ready, stop = int(sys.argv[1]), sys.argv[2], sys.argv[3]
paths = sys.argv[4:]
fds = []
for i in range(n):
    fd = os.open(paths[i % len(paths)], os.O_RDONLY)
    os.pread(fd, 4096, 0)        # the netCDF header-then-sit shape
    fds.append(fd)
with open(ready, "w") as f:
    f.write("%d\n" % len(fds))
while not os.path.exists(stop):
    time.sleep(0.2)
for fd in fds:
    os.close(fd)
