# Scrape the four gauges at HZ and write a timestamped CSV. urllib, not curl: one
# process for the whole cell, so the sample cadence is not a fork storm.
import sys, time, urllib.request
url, out, hz, stop = sys.argv[1], sys.argv[2], float(sys.argv[3]), sys.argv[4]
import os
WANT = ("lith_prefetch_resident_bytes", "lith_prefetch_budget_bytes",
        "lith_readahead_window_blocks", "lith_open_handles")
f = open(out, "w", buffering=1)
f.write("t,resident_bytes,budget_bytes,window_blocks,open_handles\n")
t0 = time.time()
period = 1.0 / hz
while not os.path.exists(stop):
    try:
        body = urllib.request.urlopen(url, timeout=2).read().decode()
    except Exception:
        time.sleep(period); continue
    v = {}
    for line in body.splitlines():
        if line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) == 2 and parts[0] in WANT:
            v[parts[0]] = parts[1]
    if v:
        f.write("%.3f,%s,%s,%s,%s\n" % (
            time.time() - t0,
            v.get("lith_prefetch_resident_bytes", ""), v.get("lith_prefetch_budget_bytes", ""),
            v.get("lith_readahead_window_blocks", ""), v.get("lith_open_handles", "")))
    time.sleep(period)
f.close()
